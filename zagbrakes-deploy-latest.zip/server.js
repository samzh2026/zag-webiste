const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = __dirname;
const DATA_FILE = path.join(ROOT, "data", "db.json");
const UPLOAD_DIR = path.join(ROOT, "uploads");
const PORT = Number(process.env.PORT || 3000);
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "88888888";
const MAX_IMAGES = 3;
const sessions = new Set();

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".txt": "text/plain; charset=utf-8",
  ".xml": "application/xml; charset=utf-8"
};

function now() {
  return new Date().toISOString();
}

function send(res, status, body, headers = {}) {
  const isBuffer = Buffer.isBuffer(body);
  res.writeHead(status, {
    "Content-Type": isBuffer ? "application/octet-stream" : "application/json; charset=utf-8",
    ...headers
  });
  res.end(isBuffer ? body : JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function readJson(req) {
  return readBody(req).then((buffer) => {
    if (!buffer.length) return {};
    return JSON.parse(buffer.toString("utf8"));
  });
}

function readDb() {
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}

function writeDb(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2), "utf8");
}

function publicDb(db) {
  const categories = [...db.categories].sort((a, b) => Number(a.sortOrder) - Number(b.sortOrder));
  const products = [...db.products].sort((a, b) => Number(a.sortOrder) - Number(b.sortOrder));
  return { categories, products };
}

function slugify(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function makeId(prefix) {
  return `${prefix}_${crypto.randomBytes(6).toString("hex")}`;
}

function authToken(req) {
  const header = req.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7) : "";
}

function requireAuth(req, res) {
  if (sessions.has(authToken(req))) return true;
  send(res, 401, { error: "Unauthorized" });
  return false;
}

function cleanFileName(fileName) {
  const ext = path.extname(fileName || "").toLowerCase();
  const safeExt = [".jpg", ".jpeg", ".png", ".webp", ".gif"].includes(ext) ? ext : ".bin";
  return `${Date.now()}-${crypto.randomBytes(5).toString("hex")}${safeExt}`;
}

// ---- Multipart parser ----

function parseMultipart(buffer, contentType) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  if (!boundaryMatch) return { fields: {}, files: {} };
  const boundary = Buffer.from("--" + (boundaryMatch[1] || boundaryMatch[2]));
  const fields = {};
  const files = {};   // fileName -> { fileName, content }
  const crlf = Buffer.from("\r\n");
  const doubleCrlf = Buffer.from("\r\n\r\n");

  let start = buffer.indexOf(boundary);
  if (start === -1) return { fields, files };
  start += boundary.length + 2; // skip first boundary + CRLF

  while (start < buffer.length) {
    const next = buffer.indexOf(boundary, start);
    if (next === -1) break;
    // Subtract 2 for the CRLF before the trailing boundary
    const partEnd = next - 2;
    const part = buffer.subarray(start, partEnd);
    const headerEnd = part.indexOf(doubleCrlf);
    if (headerEnd > -1) {
      const header = part.subarray(0, headerEnd).toString("utf8");
      const content = part.subarray(headerEnd + 4);
      const nameMatch = /name="([^"]+)"/.exec(header);
      const fileNameMatch = /filename="([^"]*)"/.exec(header);
      if (nameMatch) {
        const fieldName = nameMatch[1];
        if (fileNameMatch && fileNameMatch[1]) {
          files[fieldName] = { fileName: fileNameMatch[1], content };
        } else {
          fields[fieldName] = content.toString("utf8");
        }
      }
    }
    start = next + boundary.length + 2;
  }

  return { fields, files };
}

// ---- Build product from form fields ----

function productFromFields(fields, existing = {}) {
  const features = String(fields.features || "")
    .split(/\r?\n|,/)
    .map((item) => item.trim())
    .filter(Boolean);

  return {
    ...existing,
    sku: String(fields.sku || existing.sku || "").trim(),
    name: String(fields.name || existing.name || "").trim(),
    categoryId: String(fields.categoryId || existing.categoryId || "").trim(),
    material: String(fields.material || existing.material || "").trim(),
    vehicleModels: String(fields.vehicleModels || existing.vehicleModels || "").trim(),
    description: String(fields.description || existing.description || "").trim(),
    features,
    status: fields.status === "draft" ? "draft" : "published",
    sortOrder: Number(fields.sortOrder || existing.sortOrder || 100)
  };
}

// ---- Upload helpers ----

function saveUploadedImage(file) {
  if (!file || !file.content || !file.content.length || !file.fileName) return "";
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const fileName = cleanFileName(file.fileName);
  fs.writeFileSync(path.join(UPLOAD_DIR, fileName), file.content);
  return "/uploads/" + fileName;
}

/** Remove a single image file from disk (if it lives under /uploads/) */
function removeUploadedImage(imagePath) {
  if (!imagePath || !imagePath.startsWith("/uploads/")) return;
  const filePath = path.join(ROOT, imagePath);
  try { fs.unlinkSync(filePath); } catch (_) { /* file may already be gone */ }
}

/** Build the final images array from the incoming multipart files + existing array.
 *  The client sends image0, image1, image2 as file fields.
 *  Any position that receives a new file replaces that slot; otherwise the slot is
 *  preserved from the existing array (if any). */
function buildImages(files, existingImages = []) {
  const result = Array.isArray(existingImages) ? [...existingImages] : [];
  // Pad to MAX_IMAGES with empty strings
  while (result.length < MAX_IMAGES) result.push("");

  for (let i = 0; i < MAX_IMAGES; i++) {
    const fieldName = "image" + i;
    if (files[fieldName] && files[fieldName].content && files[fieldName].content.length) {
      // Remove old file if it existed at this slot
      if (result[i]) removeUploadedImage(result[i]);
      result[i] = saveUploadedImage(files[fieldName]);
    }
    // If no new file uploaded for this slot, keep whatever was there (or "")
  }
  // Trim trailing empty strings so we don't store unnecessary blanks
  while (result.length > 0 && result[result.length - 1] === "") result.pop();
  return result;
}

// ---- API router ----

async function handleApi(req, res, url) {
  // Health
  if (req.method === "GET" && url.pathname === "/api/health") {
    send(res, 200, { ok: true, time: now() });
    return;
  }

  // Login
  if (req.method === "POST" && url.pathname === "/api/login") {
    const body = await readJson(req);
    if (body.username !== ADMIN_USERNAME || body.password !== ADMIN_PASSWORD) {
      send(res, 401, { error: "Username or password is incorrect" });
      return;
    }
    const token = crypto.randomBytes(24).toString("hex");
    sessions.add(token);
    send(res, 200, { token });
    return;
  }

  // Public catalog
  if (req.method === "GET" && url.pathname === "/api/catalog") {
    const db = publicDb(readDb());
    const status = url.searchParams.get("status") || "published";
    const category = url.searchParams.get("category");
    const q = String(url.searchParams.get("q") || "").toLowerCase();
    let products = db.products;
    if (status !== "all") products = products.filter((item) => item.status === "published");
    if (category) products = products.filter((item) => item.categoryId === category || item.categorySlug === category);
    if (q) {
      products = products.filter((item) =>
        [item.sku, item.name, item.description, item.material, item.vehicleModels]
          .join(" ").toLowerCase().includes(q)
      );
    }
    const categoryById = new Map(db.categories.map((item) => [item.id, item]));
    send(res, 200, {
      categories: db.categories,
      products: products.map((item) => ({
        ...item,
        category: categoryById.get(item.categoryId) || null
      }))
    });
    return;
  }

  // Admin catalog
  if (req.method === "GET" && url.pathname === "/api/admin/catalog") {
    if (!requireAuth(req, res)) return;
    send(res, 200, publicDb(readDb()));
    return;
  }

  // ---- Categories ----

  if (req.method === "POST" && url.pathname === "/api/admin/categories") {
    if (!requireAuth(req, res)) return;
    const body = await readJson(req);
    const db = readDb();
    if (!String(body.name || "").trim()) return send(res, 400, { error: "Category name is required" });
    const category = {
      id: makeId("cat"),
      name: String(body.name).trim(),
      slug: slugify(body.slug || body.name),
      description: String(body.description || "").trim(),
      sortOrder: Number(body.sortOrder || 100),
      createdAt: now(),
      updatedAt: now()
    };
    db.categories.push(category);
    writeDb(db);
    send(res, 201, category);
    return;
  }

  const categoryMatch = /^\/api\/admin\/categories\/([^/]+)$/.exec(url.pathname);

  if (categoryMatch && req.method === "PUT") {
    if (!requireAuth(req, res)) return;
    const body = await readJson(req);
    const db = readDb();
    const category = db.categories.find((item) => item.id === categoryMatch[1]);
    if (!category) return send(res, 404, { error: "Category not found" });
    category.name = String(body.name || category.name).trim();
    category.slug = slugify(body.slug || category.slug || category.name);
    category.description = String(body.description || "").trim();
    category.sortOrder = Number(body.sortOrder || category.sortOrder || 100);
    category.updatedAt = now();
    writeDb(db);
    send(res, 200, category);
    return;
  }

  if (categoryMatch && req.method === "DELETE") {
    if (!requireAuth(req, res)) return;
    const db = readDb();
    if (db.products.some((item) => item.categoryId === categoryMatch[1])) {
      return send(res, 409, { error: "Move or delete products in this category first" });
    }
    db.categories = db.categories.filter((item) => item.id !== categoryMatch[1]);
    writeDb(db);
    send(res, 200, { ok: true });
    return;
  }

  // ---- Products ----

  if (req.method === "POST" && url.pathname === "/api/admin/products") {
    if (!requireAuth(req, res)) return;
    const { fields, files } = parseMultipart(await readBody(req), req.headers["content-type"]);
    const images = buildImages(files, []);
    const product = productFromFields(fields, {
      id: makeId("prod"),
      images,
      createdAt: now(),
      updatedAt: now()
    });
    if (!product.name || !product.categoryId) return send(res, 400, { error: "Product name and category are required" });
    const db = readDb();
    db.products.push(product);
    writeDb(db);
    send(res, 201, product);
    return;
  }

  const productMatch = /^\/api\/admin\/products\/([^/]+)$/.exec(url.pathname);

  if (productMatch && req.method === "PUT") {
    if (!requireAuth(req, res)) return;
    const { fields, files } = parseMultipart(await readBody(req), req.headers["content-type"]);
    const db = readDb();
    const index = db.products.findIndex((item) => item.id === productMatch[1]);
    if (index === -1) return send(res, 404, { error: "Product not found" });
    const existingImages = db.products[index].images || (db.products[index].image ? [db.products[index].image] : []);
    const images = buildImages(files, existingImages);
    db.products[index] = productFromFields(fields, {
      ...db.products[index],
      images,
      updatedAt: now()
    });
    // Clean up legacy single-image field
    delete db.products[index].image;
    writeDb(db);
    send(res, 200, db.products[index]);
    return;
  }

  if (productMatch && req.method === "DELETE") {
    if (!requireAuth(req, res)) return;
    const db = readDb();
    const product = db.products.find((item) => item.id === productMatch[1]);
    if (product) {
      const imgs = product.images || (product.image ? [product.image] : []);
      imgs.forEach((img) => removeUploadedImage(img));
    }
    db.products = db.products.filter((item) => item.id !== productMatch[1]);
    writeDb(db);
    send(res, 200, { ok: true });
    return;
  }

  send(res, 404, { error: "API route not found" });
}

// ---- Static file server ----

function serveStatic(req, res, url) {
  let filePath = decodeURIComponent(url.pathname);
  if (filePath === "/") filePath = "/index.html";
  filePath = path.normalize(filePath).replace(/^(\.\.[/\\])+/, "");
  const absolutePath = path.join(ROOT, filePath);

  if (!absolutePath.startsWith(ROOT)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(absolutePath, (error, data) => {
    if (error) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Not found");
      return;
    }
    const contentType = mimeTypes[path.extname(absolutePath).toLowerCase()] || "application/octet-stream";
    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://" + (req.headers.host || "localhost"));
  if (url.pathname.startsWith("/api/")) {
    handleApi(req, res, url).catch((error) => {
      console.error("API error:", error);
      send(res, 500, { error: error.message || "Server error" });
    });
    return;
  }
  serveStatic(req, res, url);
});

server.listen(PORT, () => {
  console.log("ZAG BRAKES website running at http://localhost:" + PORT);
  console.log("Admin page: http://localhost:" + PORT + "/admin.html");
});
